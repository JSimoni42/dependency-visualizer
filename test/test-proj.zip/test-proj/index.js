import flim from "./imported-1";
import shim from "./sub-dir/imported-2"
import React from "react";